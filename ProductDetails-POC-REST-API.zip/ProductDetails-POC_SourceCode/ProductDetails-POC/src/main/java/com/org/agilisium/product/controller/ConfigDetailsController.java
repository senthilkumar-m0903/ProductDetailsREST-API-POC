package com.org.agilisium.product.controller;

import com.org.agilisium.product.pojo.ConfigAWS;
import com.org.agilisium.product.service.ConfigServiceAWS;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/getconfigdetails")
public class ConfigDetailsController {

    private final ConfigServiceAWS configServiceAWS;


    public ConfigDetailsController(ConfigServiceAWS configServiceAWS) {
        this.configServiceAWS = configServiceAWS;
    }

    @GetMapping
    public List<ConfigAWS> getConfigAWS() {

        return configServiceAWS.getConfigList();

    }
}
