package com.org.agilisium.product.controller;

import com.org.agilisium.product.pojo.ProductAWS;
import com.org.agilisium.product.service.ProductServiceAWS;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/getproductdetails")
public class ProductDetailsController {

    private final ProductServiceAWS productServiceAWS;

    public ProductDetailsController(ProductServiceAWS productServiceAWS) {
        this.productServiceAWS = productServiceAWS;
    }

    @GetMapping
    public List<ProductAWS> getAllProducts() {

        return productServiceAWS.getAllProduct();

    }
}
