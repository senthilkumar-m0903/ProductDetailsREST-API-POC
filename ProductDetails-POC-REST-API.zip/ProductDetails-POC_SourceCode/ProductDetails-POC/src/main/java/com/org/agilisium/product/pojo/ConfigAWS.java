package com.org.agilisium.product.pojo;

public class ConfigAWS {

    private String URL;
    private String method;
    private String purpose;

    public ConfigAWS(String URL, String method, String purpose) {
        this.URL = URL;
        this.method = method;
        this.purpose = purpose;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }
}
