package com.org.agilisium.product.service;

import com.org.agilisium.product.pojo.ProductAWS;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class ProductServiceAWS {

    private List<ProductAWS> awsProductList = Arrays.asList(
            new ProductAWS(1, "m5.xlarge", "$0.192 per Hour"),
            new ProductAWS(2, "m5.2xlarge", "$0.384 per Hour"),
            new ProductAWS(3, " m5.12xlarge", "$2.304 per Hour"),
            new ProductAWS(4, "m5.16xlarge", "$3.072 per Hour"),
            new ProductAWS(5, "m5.24xlarge", "$4.608 per Hour")
    );

    public List<ProductAWS> getAllProduct() {

        return awsProductList;
    }
}
