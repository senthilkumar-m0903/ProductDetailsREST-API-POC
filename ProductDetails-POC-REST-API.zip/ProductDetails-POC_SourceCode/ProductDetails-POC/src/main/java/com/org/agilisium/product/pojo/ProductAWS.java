package com.org.agilisium.product.pojo;

public class ProductAWS {

    private Integer vmID;
    private String type;
    private String price;

    public ProductAWS(Integer vmID, String type, String price) {
        this.vmID = vmID;
        this.type = type;
        this.price = price;
    }

    public Integer getVmID() {
        return vmID;
    }

    public void setVmID(Integer vmID) {
        this.vmID = vmID;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
