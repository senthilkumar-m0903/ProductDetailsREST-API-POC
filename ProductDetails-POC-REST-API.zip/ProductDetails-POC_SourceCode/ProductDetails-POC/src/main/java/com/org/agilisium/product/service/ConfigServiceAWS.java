package com.org.agilisium.product.service;

import com.org.agilisium.product.pojo.ConfigAWS;
import org.springframework.stereotype.Service;


import java.util.Arrays;
import java.util.List;

@Service
public class ConfigServiceAWS {

    private List<ConfigAWS> awsConfigList = Arrays.asList(
            new ConfigAWS("http://<IPORDomainName>:<PORT>/api/getproductdetails", "GET", "API To Get List Of Products Details")
    );

    public List<ConfigAWS> getConfigList() {

        return awsConfigList;
    }
}
