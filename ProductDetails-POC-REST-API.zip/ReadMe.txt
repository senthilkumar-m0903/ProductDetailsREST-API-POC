Created the below REST-GET API Endpoints with different basic authentication.

Technology : Spring-Boot
Compiled Java Version : 1.8
Authentication : In-Memory Authentication
Dependency Added : spring-boot-starter-web,spring-boot-starter-security

Source Code Path: /ProductDetails-POC_SourceCode/*
War File Path : /ProductDetails-POC_War/*

Please find the configuration steps below :

1.Deploy the "ProductDetails-POC.war" in tomcat(Version 8.0.43 or above) webapps directory.
2.Start the tomcat and verify the same(http://localhost:8080/ProductDetails-POC).
3.Open "Postman" and paste the below URL's with different credentials in each tab.
4.Click on the "Authorization", under the each tab, Choose the "Basic Auth" from the "type" dropdown.
5.Provide the following credentials for each REST Get API and click on the "Send" button.

URL : http://localhost:8080/ProductDetails-POC/api/getproductdetails/
UserName : configaws
Password : configaws123

URL : http://localhost:8080/ProductDetails-POC/api/getconfigdetails
UserName : productaws
Password : productaws123
